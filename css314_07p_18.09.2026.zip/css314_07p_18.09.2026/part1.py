import threading
import random
import time

TOTAL_POINTS = 50_000_000
NUM_THREADS = 4

total_hits = 0




def worker(points):
    global total_hits
    
    local_random = random.Random()
    
    for _ in range(points):
        x = local_random.random()
        y = local_random.random()
        
        if x * x + y * y <= 1:
            total_hits += 1

total_hits = 0

points_per_thread = TOTAL_POINTS // NUM_THREADS

threads = []

start = time.perf_counter()

for _ in range(NUM_THREADS):
    thread = threading.Thread(
        target=worker,
        args=(points_per_thread,)
    )
    
    threads.append(thread)
    thread.start()

for thread in threads:
    thread.join()

end = time.perf_counter()

pi = 4 * total_hits / TOTAL_POINTS

print("Total hits:", total_hits)
print("Pi:", pi)
print("Runtime:", (end - start) * 1000, "ms")



lock = threading.Lock()
total_hits = 0


def worker_reduction(points, results, index):
    local_hits = 0
    
    local_random = random.Random()
    
    for _ in range(points):
        x = local_random.random()
        y = local_random.random()
        
        if x * x + y * y <= 1:
            local_hits += 1
    
    results[index] = local_hits


TOTAL_POINTS = 100_000_000
def run_reduction(num_threads):
    
    points_per_thread = TOTAL_POINTS // num_threads
    
    results = [0] * num_threads
    threads = []
    
    start = time.perf_counter()
    
    for i in range(num_threads):
        thread = threading.Thread(
            target=worker_reduction,
            args=(points_per_thread, results, i)
        )
        
        threads.append(thread)
        thread.start()
    
    for thread in threads:
        thread.join()
    
    total_hits = sum(results)
    
    end = time.perf_counter()
    
    pi = 4 * total_hits / TOTAL_POINTS
    runtime = (end - start) * 1000
    
    return pi, runtime

thread_counts = [1, 2, 4, 8, 16, 32]

results = {}

for threads in thread_counts:
    pi, runtime = run_reduction(threads)
    
    results[threads] = runtime
    
    print(
        f"{threads} threads: "
        f"Pi = {pi:.6f}, "
        f"Runtime = {runtime:.2f} ms"
    )


